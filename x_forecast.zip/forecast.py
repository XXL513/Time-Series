import random
import numpy as np
from math import *
import scipy.optimize as opt
import prettytable as pt

import numpy
import matplotlib.pyplot as plt
from pandas import read_excel
import math
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error


def diff(b):
    """一阶差分"""
    c = []
    for t in range(1, len(b)):
        c.append(b[t]-b[t-1])
    return c


def get_mse(records_real, records_predict):
    """
    均方误差：估计值与真值 偏差
    """
    if len(records_real) == len(records_predict):
        return sum([(x - y) ** 2 for x, y in zip(records_real, records_predict)]) / len(records_real)
    else:
        return None


def get_rmse(records_real, records_predict):
    """
    均方根误差：是均方误差的算术平方根
    """
    mse = get_mse(records_real, records_predict)
    if mse:
        return sqrt(mse)
    else:
        return None


def devide(series, ra = 0.7):
    '''

    :param series: input data
    :param ra: ratio of testing set
    :return:training set, testing set
    '''
    train_size = int(ra * len(series))
    train, test = series[0:train_size, :], series[train_size:len(series), :]  # 训练集和测试集
    return train, test


def ForecastARkf(y, h):
    n = len(y)
    a = np.zeros(n)
    p = np.zeros(n)
    a[0] = y[0]
    p[0] = 10000
    k = np.zeros(n)
    v = np.zeros(n)
    def fu(mypa):
        q = abs(mypa[0])
        co = mypa[1]
        w = 1- exp(-abs(mypa[2]))
        z = 1
        likelihood = sigmae = 0
        for t in range(1, n):
            k[t] = (z * w * p[t - 1]) / (z ** 2 * p[t - 1] + 1)
            p[t] = w ** 2 * p[t - 1] - w * z * k[t] * p[t - 1] + q
            v[t] = y[t] - z * a[t - 1]
            a[t] = co + w * a[t - 1] + k[t] * v[t]
            sigmae = sigmae + (v[t] ** 2 / (z ** 2 * p[t - 1] + 1))
            likelihood = likelihood + .5 * log(2 * pi) + .5 + .5 * log(z ** 2 * p[t - 1] + 1)
        return likelihood + .5 * n * log(sigmae / n)

    results = opt.fmin(fu, [.2, 1, 2])

    z = 1
    q = abs(results[0])
    co = abs(results[1])
    w = 1 - exp(-abs(results[2]))
    sigmae = 0
    for t in range(1, n):
        k[t] = (z * w * p[t - 1]) / (z ** 2 * p[t - 1] + 1)
        p[t] = w ** 2 * p[t - 1] - w * z * k[t] * p[t - 1] + q
        v[t] = y[t] - z * a[t - 1]
        a[t] = co + w * a[t - 1] + k[t] * v[t]
        sigmae = sigmae + (v[t] ** 2 / (z ** 2 * p[t - 1] + 1))

    Forec = []
    Forec.append(a[len(y) - 1])
    for i in range(1, h):
        Forec.append(co + w * Forec[i - 1])
    return Forec


def ForecastAR(y, h):
    n = len(y)
    state = np.zeros(n)
    v = np.zeros(n)
    state[0] = y[0]

    def logLikConc(myparam):
        w = 1 - exp(-abs(myparam[0]))
        gamma = abs(myparam[1])
        co = abs(myparam[2])
        for t in range(1, n):
            v[t] = y[t] - state[t - 1]
            state[t] = co + w * state[t - 1] + gamma * v[t]
        return sum(v[1:n] ** 2)

    result = opt.fmin(logLikConc, [2, .2, 1])

    w = 1 - exp(-abs(result[0]))
    gamma = abs(result[1])
    co = abs(result[2])
    for t in range(1, n):
        v[t] = y[t] - state[t - 1]
        state[t] = co + w * state[t - 1] + gamma * v[t]

    Forec = []
    Forec.append(state[len(y) - 1])
    for i in range(1, h):
        Forec.append(co + w * Forec[i - 1])
    return Forec


def ForecastTheta(y, h):
    n = len(y)
    state = np.zeros(n)
    v = np.zeros(n)
    state[0] = y[0]

    def logLikConc(myparam):
        w = 1
        gamma = abs(myparam[0])
        co = abs(myparam[1])
        for t in range(1, n):
            v[t] = y[t] - state[t - 1]
            state[t] = co + w * state[t - 1] + gamma * v[t]
        return sum(v[1:n] ** 2)

    result = opt.fmin(logLikConc, [.3, 1])

    w = 1
    gamma = abs(result[0])
    co = abs(result[1])
    for t in range(1, n):
        v[t] = y[t] - state[t - 1]
        state[t] = co + w * state[t - 1] + gamma * v[t]

    Forec = []
    Forec.append(state[len(y) - 1])
    for i in range(1, h):
        Forec.append(co + w * Forec[i - 1])
    return Forec


def ForecastThetakf(y, h):
    n = len(y)
    a = np.zeros(n)
    p = np.zeros(n)
    a[0] = y[0]
    p[0] = 10000
    k = np.zeros(n)
    v = np.zeros(n)

    def funcTheta(parameters):
        q = abs(parameters[0])
        co = abs(parameters[1])
        z = w = 1
        likelihood = sigmae = 0
        for t in range(1, n):
            k[t] = (z * w * p[t - 1]) / (z ** 2 * p[t - 1] + 1)
            p[t] = w ** 2 * p[t - 1] - w * z * k[t] * p[t - 1] + q
            v[t] = y[t] - z * a[t - 1]
            a[t] = co + w * a[t - 1] + k[t] * v[t]
            sigmae = sigmae + (v[t] ** 2 / (z ** 2 * p[t - 1] + 1))
            likelihood = likelihood + .5 * log(2 * pi) + .5 + .5 * log(z ** 2 * p[t - 1] + 1)
        return likelihood + .5 * n * log(sigmae / n)

    results = opt.fmin(funcTheta, [.3, 1])

    q = abs(results[0])
    co = abs(results[1])
    z = w = 1
    for t in range(1, n):
        k[t] = (z * w * p[t - 1]) / (z ** 2 * p[t - 1] + 1)
        p[t] = w ** 2 * p[t - 1] - w * z * k[t] * p[t - 1] + q
        v[t] = y[t] - z * a[t - 1]
        a[t] = co + w * a[t - 1] + k[t] * v[t]

    Forecast = []
    Forecast.append(a[n - 1])
    for i in range(1, h):
        Forecast.append(co + Forecast[i - 1])
    return Forecast


def ForecastDamped(y, h):
    obs = len(y)
    damped = np.zeros((obs, 2))
    damped[0, 0] = y[0]
    damped[0, 1] = 0
    inn = np.zeros(obs)

    def fmsoe(param):
        k1 = abs(param[0])
        k2 = abs(param[1])
        k3 = abs(param[2])
        for t in range(1, obs):
            inn[t] = y[t] - damped[t - 1, 0] - k3 * damped[t - 1, 1]
            damped[t, 0] = damped[t - 1, 0] + k3 * damped[t - 1, 1] + k1 * inn[t]
            damped[t, 1] = k3 * damped[t - 1, 1] + k2 * inn[t]
        return sum(inn[0:obs] ** 2) / obs

    result = opt.fmin(fmsoe, [random.random(), random.random(), random.random()])

    k1 = abs(result[0])
    k2 = abs(result[1])
    k3 = abs(result[2])
    if k3 > 1: k3 = 1

    for t in range(1, obs):
        inn[t] = y[t] - damped[t - 1, 0] - k3 * damped[t - 1, 1]
        damped[t, 0] = damped[t - 1, 0] + k3 * damped[t - 1, 1] + k1 * inn[t]  # (y[t]-holt[t-1,1]-holt[t-1,2])
        damped[t, 1] = k3 * damped[t - 1, 1] + k2 * inn[t]  # (y[t]-holt[t-1,1]-holt[t-1,2])
    Forecast = []
    Forecast.append(damped[obs - 1, 0] + k3 * damped[obs - 1, 1])
    for i in range(1, h):
        Forecast.append(Forecast[i - 1] + damped[obs - 1, 1] * k3 ** i)
    return Forecast


def Forecast_method(MM, steps, method='All'):
    '''

    :param MM: input data
    :param steps: count of testing set
    :param method: selection of forecasting methods, default is "All"
    :return:
    '''
    if method != 'All':
        Method = np.zeros(steps)
        Err = np.zeros(steps)
        sErr = np.zeros(steps)
        y = MM[:-steps]

        if method == 'ForecastAR':
            Method = ForecastAR(y, steps)
        elif method == 'ForecastARkf':
            Method = ForecastARkf(y, steps)
        elif method == 'ForecastTheta':
            Method = ForecastTheta(y, steps)
        elif method == 'ForecastThetakf':
            Method = ForecastThetakf(y, steps)
        elif method == 'ForecastDamped':
            Method = ForecastDamped(y, steps)

        Err = np.array(MM[-steps:]) - Method
        denominator = np.mean(np.array(list(map(abs, diff(y)))))
        sErr = Err / denominator
        numerator = np.array(list(map(abs, list(Err[0:steps]))))
        denominator = np.array(list(map(abs, Method[0:steps]))) + np.array(list(map(abs, MM[-steps:])))
        MAPE = np.mean(200 * numerator / denominator)
        MASE = np.mean(np.array(list(map(abs, list(sErr[0:steps])))))

        tb = pt.PrettyTable()
        names = [str(i + 1) for i in range(steps)]
        tb.field_names = [""] + names + ["RMSE"]
        tb.add_row(["Observation"] + MM[-steps:] + [""])
        Method = list(np.around(Method, 3))
        Err = list(np.around(Err, 3))
        tb.add_row(["Prediction"] + Method + [round(get_rmse(MM[-steps:], Method),3)])
        tb.add_row(["Err"] + Err + [""])
        print(tb)

        return MAPE, MASE

    Method1 = np.zeros(steps)
    Method2 = np.zeros(steps)
    Method3 = np.zeros(steps)
    Method4 = np.zeros(steps)
    Method5 = np.zeros(steps)
    Err1 = np.zeros(steps)
    Err2 = np.zeros(steps)
    Err3 = np.zeros(steps)
    Err4 = np.zeros(steps)
    Err5 = np.zeros(steps)
    sErr1 = np.zeros(steps)
    sErr2 = np.zeros(steps)
    sErr3 = np.zeros(steps)
    sErr4 = np.zeros(steps)
    sErr5 = np.zeros(steps)

    y = MM[:-steps]
    # For the M4 competition use y<-MM[[g]][[2]]
    Method1 = ForecastAR(y, steps)
    Method2 = ForecastARkf(y, steps)
    Method3 = ForecastTheta(y, steps)
    Method4 = ForecastThetakf(y, steps)
    Method5 = ForecastDamped(y, steps)

    Err1 = np.array(MM[-steps:]) - Method1
    Err2 = np.array(MM[-steps:]) - Method2
    Err3 = np.array(MM[-steps:]) - Method3
    Err4 = np.array(MM[-steps:]) - Method4
    Err5 = np.array(MM[-steps:]) - Method5

    denominator = np.mean(np.array(list(map(abs, diff(y)))))
    sErr1 = Err1 / denominator
    sErr2 = Err2 / denominator
    sErr3 = Err3 / denominator
    sErr4 = Err4 / denominator
    sErr5 = Err5 / denominator

    ResultsMAPE = np.zeros((steps, 9))

    for s in range(steps):
        sMAPE = np.zeros(5)

        numerator = np.array(list(map(abs, list(Err1[0:s + 1]))))
        denominator = np.array(list(map(abs, Method1[0:s + 1]))) + np.array(list(map(abs, MM[-steps:][0:s + 1])))
        sMAPE[0] = np.mean(200 * numerator / denominator)

        numerator = np.array(list(map(abs, list(Err2[0:s + 1]))))
        denominator = np.array(list(map(abs, Method2[0:s + 1]))) + np.array(list(map(abs, MM[-steps:][0:s + 1])))
        sMAPE[1] = np.mean(200 * numerator / denominator)

        numerator = np.array(list(map(abs, list(Err3[0:s + 1]))))
        denominator = np.array(list(map(abs, Method3[0:s + 1]))) + np.array(list(map(abs, MM[-steps:][0:s + 1])))
        sMAPE[2] = np.mean(200 * numerator / denominator)

        numerator = np.array(list(map(abs, list(Err4[0:s + 1]))))
        denominator = np.array(list(map(abs, Method4[0:s + 1]))) + np.array(list(map(abs, MM[-steps:][0:s + 1])))
        sMAPE[3] = np.mean(200 * numerator / denominator)

        numerator = np.array(list(map(abs, list(Err5[0:s + 1]))))
        denominator = np.array(list(map(abs, Method5[0:s + 1]))) + np.array(list(map(abs, MM[-steps:][0:s + 1])))
        sMAPE[4] = np.mean(200 * numerator / denominator)

        ResultsMAPE[s, 0] = sMAPE[0]
        ResultsMAPE[s, 1] = sMAPE[1]
        ResultsMAPE[s, 2] = sMAPE[2]
        ResultsMAPE[s, 3] = sMAPE[3]
        ResultsMAPE[s, 4] = sMAPE[4]
        ResultsMAPE[s, 5] = sMAPE[0] / sMAPE[1]
        ResultsMAPE[s, 6] = sMAPE[0] / sMAPE[2]
        ResultsMAPE[s, 7] = sMAPE[0] / sMAPE[3]
        ResultsMAPE[s, 8] = sMAPE[0] / sMAPE[4]

    ResultsMASE = np.zeros((steps, 9))

    for s in range(steps):
        sMASE = np.zeros(5)

        sMASE[0] = np.mean(np.array(list(map(abs, list(sErr1[0:s + 1])))))
        sMASE[1] = np.mean(np.array(list(map(abs, list(sErr2[0:s + 1])))))
        sMASE[2] = np.mean(np.array(list(map(abs, list(sErr3[0:s + 1])))))
        sMASE[3] = np.mean(np.array(list(map(abs, list(sErr4[0:s + 1])))))
        sMASE[4] = np.mean(np.array(list(map(abs, list(sErr5[0:s + 1])))))

        ResultsMASE[s, 0] = sMASE[0]
        ResultsMASE[s, 1] = sMASE[1]
        ResultsMASE[s, 2] = sMASE[2]
        ResultsMASE[s, 3] = sMASE[3]
        ResultsMASE[s, 4] = sMASE[4]
        ResultsMASE[s, 5] = sMASE[0] / sMASE[1]
        ResultsMASE[s, 6] = sMASE[0] / sMASE[2]
        ResultsMASE[s, 7] = sMASE[0] / sMASE[3]
        ResultsMASE[s, 8] = sMASE[0] / sMASE[4]

    tb = pt.PrettyTable()
    names = [str(i+1) for i in range(steps)]
    tb.field_names = [""] + names + ["Test RMSE"]
    tb.add_row(["Observation"] + MM[-steps:] + [""])
    Method1 = list(np.around(Method1, 3))
    Method2 = list(np.around(Method2, 3))
    Method3 = list(np.around(Method3, 3))
    Method4 = list(np.around(Method4, 3))
    Method5 = list(np.around(Method5, 3))

    tb.add_row(["Method1"] + Method1 + [round(get_rmse(MM[-steps:], Method1),3)])
    tb.add_row(["Method2"] + Method2 + [round(get_rmse(MM[-steps:], Method2),3)])
    tb.add_row(["Method3"] + Method3 + [round(get_rmse(MM[-steps:], Method3),3)])
    tb.add_row(["Method4"] + Method4 + [round(get_rmse(MM[-steps:], Method4),3)])
    tb.add_row(["Method5"] + Method5 + [round(get_rmse(MM[-steps:], Method5),3)])
    print(tb)

    return ResultsMASE, ResultsMAPE

############################# LSTM #############################
# convert an array of values into a dataset matrix
def create_dataset(dataset, look_back = 1): # 后一个数据和前look_back个数据有关系
    dataX, dataY = [], []
    for i in range(len(dataset) - look_back - 1):
        a = dataset[i:(i+look_back), 0]
        dataX.append(a)
        dataY.append(dataset[i+look_back, 0])
    return numpy.array(dataX), numpy.array(dataY)  # 生成输入数据和输出数据

def LSTM(series, look_back, ra):
    """

    :param series: input
    :param look_back:
    :return:ResultsMASE
    """
    # normalize the dataset
    scaler = MinMaxScaler(feature_range=(0, 1))  # 归一化0-1
    dataset = scaler.fit_transform(series)

    train, test = devide(series, ra)
    trainX, trainY = create_dataset(train, look_back)  # 训练输入输出
    testX, testY = create_dataset(test, look_back)  # 测试输入输出

    # reshape input to be [samples, time steps, features]#注意转化数据维数
    trainX = numpy.reshape(trainX, (trainX.shape[0], 1, trainX.shape[1]))
    testX = numpy.reshape(testX, (testX.shape[0], 1, testX.shape[1]))

    # 建立LSTM模型
    model = Sequential()
    model.add(LSTM(11, input_shape=(1, look_back)))  # 隐层11个神经元 （可以断调整此参数提高预测精度）
    model.add(Dense(1))
    model.compile(loss='mean_squared_error', optimizer='adam')  # 评价函数mse，优化器adam
    model.fit(trainX, trainY, epochs=100, batch_size=1, verbose=2)  # 100次迭代
    trainPredict = model.predict(trainX)
    testPredict = model.predict(testX)

    # 数据反归一化
    trainPredict = scaler.inverse_transform(trainPredict)
    trainY = scaler.inverse_transform([trainY])
    testPredict = scaler.inverse_transform(testPredict)
    testY = scaler.inverse_transform([testY])

    trainScore = math.sqrt(mean_squared_error(trainY[0], trainPredict[:, 0]))
    print('Train Score: %.2f RMSE' % (trainScore))
    testScore = math.sqrt(mean_squared_error(testY[0], testPredict[:, 0]))
    print('Test Score: %.2f RMSE' % (testScore))

    return testScore